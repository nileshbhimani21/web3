import { AccountButton, ConnectButton, useWeb3Modal } from '@web3modal/react'
import Head from 'next/head'
import { useAccount, useBalance } from 'wagmi'

export default function YourAppContent() {
  const { isConnected, address } = useAccount()
  const { open } = useWeb3Modal()
  const { data, isError, isLoading } = useBalance({
    address: address,
  })

  if (isLoading) return <div>Fetching balance…</div>
  if (isError) return <div>Error fetching balance</div>
  return (
    <>
      <Head>
        <title>Next web3</title>
      </Head>
      <main>
        {/* <Web3Button /> */}
        {/* or */}
        {!isConnected ? <ConnectButton /> : <>{data?.formatted} {data?.symbol} <AccountButton /></>}
        {/* or */}
        {!isConnected && <button onClick={() => open()}>Open Modal</button>}
      </main>
    </>
  )
}
