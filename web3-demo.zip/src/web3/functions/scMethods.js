import { toast } from "react-toastify";
import Web3 from "web3";

function getInstance(web3, address, abi) {

  return new Promise(async (resolve, reject) => {
    if (web3 && web3 !== '') {
      try {
        let Instance = await new web3.eth.Contract(
          abi, address
        );

        if (Instance) {
          resolve(Instance);
        } else {
          reject({ error: "Issue with instance" });
        }
      } catch (error) {
        reject(error);
      }
    }
  });
};

function totalSupply(instance, walletAddress) {
  return new Promise(async (resolve, reject) => {
    try {
      await instance?.methods
        .totalSupply()
        .call({ from: walletAddress }, (err, data) => {
          resolve(data);
        });
    } catch (error) {
      reject({ error: error });
    }
  });
}

function balanceOf(instance, walletAddress, networkDetails) {
  return new Promise(async (resolve, reject) => {
    try {
      await instance?.methods
        .balanceOf(walletAddress)
        .call({ from: walletAddress }, (err, data) => {
          if (err) {
            reject({ error: "Error in fetching token_address" });
          } else {
            if (data) {
              resolve(Web3.utils.fromWei(data))
            } else {
              toast.error("Error in fetching token_address")
            }
          }
          resolve(data);
        });
    } catch (error) {
      reject({ error: error });
    }
  });
}

export const scMethods = {
  getInstance,
  totalSupply,
  balanceOf,
}

