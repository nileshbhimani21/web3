

import React, { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { Web3Provider } from '../contexts/web3Context';

import {
  listenAccountChange,
  listenNetworkChange, loadBlockChainData, loadWeb3
} from '../functions/web3';

const Providers = ({ children }) => {


  const [loading, setLoading] = useState(false);

  const [networkDetails, setNetworkDetails] = useState({
    isUpdated: false,
    address: '',
    web3: '',
    connected: '',
    connectTag: '',
    chainData: '',
    wallet: '',
    chainId: '',
    networkId: '',
    balance: '',
    isAdmin: false,
    tokenBalance: 0,
  })

  const resetApp = async () => {
    setNetworkDetails({
      isUpdated: false,
      address: '',
      web3: '',
      connected: false,
      connectTag: '',
      chainData: '',
      wallet: '',
      chainId: '',
      networkId: '',
      balance: '',
      isAdmin: false,
      tokenBalance: 0,
    })
    const web3 = window.web3
    //close -> disconnect
    localStorage.removeItem("wallet_name", "injected");
    if (
      web3 &&
      web3.currentProvider &&
      web3.currentProvider.disconnect
    ) {
      await web3.currentProvider.disconnect()
    }
  }

  const handleConnect = async () => {
    const metaMaskInstalled = typeof window.web3 !== 'undefined'
    if (metaMaskInstalled) {
      setLoading(true)
      await loadWeb3(setLoading)
      await loadBlockChainData(
        setNetworkDetails,
        networkDetails,
        setLoading,
      )
      await listenAccountChange(
        setNetworkDetails,
        networkDetails,
        setLoading,
        resetApp,
      )
      await listenNetworkChange(
        setNetworkDetails,
        networkDetails,
        setLoading,
        resetApp,
      )
    } else {
      toast.info(
        'Metamask Extension Not Found ! Please Install Metamask to Connect',
      )
    }
  }

  const handleDisconnect = async () => {
    setLoading(true)
    await loadWeb3(setLoading)
    await window.web3.eth.currentProvider.disconnect()
    resetApp()
  }

  useEffect(() => {
    let injected = localStorage.getItem("injected");
    if (injected && injected !== undefined) {
      let walletName = localStorage.getItem("wallet_name");
      if (walletName && walletName !== undefined) {
        if (walletName === "metamask") {
          handleConnect();
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);





  return (
    <>
      <Web3Provider
        value={{
          loadWeb3,
          loading,
          setLoading,
          networkDetails,
          setNetworkDetails,
          loadBlockChainData,
          listenAccountChange,
          listenNetworkChange,
          handleConnect,
          handleDisconnect,
          resetApp
        }}
      >
        {/* {loading && <Loader />} */}
        {children}
      </Web3Provider>
    </>
  )
}


export default Providers

