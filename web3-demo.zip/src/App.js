import { useContext } from 'react';
import './App.css';
import logo from './logo.svg';
import { Web3Context } from './web3/contexts/web3Context';
import Providers from './web3/providers';

function App() {
  return (
    <Providers>
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Edit <code>src/App.js</code> and save to reload.
          </p>
          <App2 />
        </header>
      </div>
    </Providers>
  );
}

export default App;


export function App2() {
  const { networkDetails, handleConnect, resetApp } = useContext(Web3Context);
  console.log(networkDetails, 'networkDetails')
  return (
    <button type='button' onClick={() => { networkDetails.address === '' ? handleConnect() : resetApp() }}>{networkDetails.address !== '' ? networkDetails.address : "Connect"}</button>
  );
}
